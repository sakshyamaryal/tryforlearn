### I have this problem/would like to have this functionality

### These are mPDF and PHP versions I am using

### This is a PHP code snippet I use

```
<?php


```

### This is a HTML code snippet I use

```

```
