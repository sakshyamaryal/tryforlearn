/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'az', {
	title: 'TeX ilə düsturları',
	button: 'Riyaziyyat',
	dialogInput: 'TeX-ini burada yazın',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'TeX üzə nizamnaməsi',
	loading: 'yükləmə...',
	pathName: 'riyaziyyat'
} );
